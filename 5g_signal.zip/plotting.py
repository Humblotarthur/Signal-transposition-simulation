"""
plotting.py
Fonctions matplotlib pour visualiser le signal avant upsampling
et après transposition fréquentielle.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


def compute_spectrum(signal: np.ndarray, fs: float):
    """
    Calcule le spectre en fréquence d'un signal complexe.

    Retourne:
        freqs_mhz : fréquences en MHz (centrées sur 0)
        spectrum_db : amplitude en dB
    """
    N = len(signal)
    spectrum = np.fft.fftshift(np.fft.fft(signal))
    freqs = np.fft.fftshift(np.fft.fftfreq(N, d=1.0 / fs))
    spectrum_db = 20 * np.log10(np.abs(spectrum) / N + 1e-12)
    return freqs / 1e6, spectrum_db


def plot_before_after(
    signal_before: np.ndarray,
    signal_after: np.ndarray,
    fs_before: float,
    fs_after: float,
    f_shift: float,
    save_path: str = None
):
    """
    Affiche 4 graphes :
      - Domaine temporel avant (I et Q)
      - Spectre avant
      - Domaine temporel après transposition
      - Spectre après transposition (zoomé autour de f_shift)

    Paramètres:
        signal_before : signal baseband avant upsampling/transposition
        signal_after  : signal après upsampling + transposition
        fs_before     : sample rate du signal avant (Hz)
        fs_after      : sample rate du signal après (Hz)
        f_shift       : fréquence de transposition (Hz)
        save_path     : chemin pour sauvegarder l'image (optionnel)
    """
    fig = plt.figure(figsize=(16, 10))
    fig.patch.set_facecolor('#0f1117')

    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.45, wspace=0.35)

    color_i = '#00d4ff'
    color_q = '#ff6b35'
    color_spec_before = '#7bed9f'
    color_spec_after = '#ffd32a'

    # ── 1. Domaine temporel AVANT ─────────────────────────────────────────
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.set_facecolor('#1a1d2e')

    n_show = min(300, len(signal_before))
    t_us = np.arange(n_show) / fs_before * 1e6

    ax1.plot(t_us, np.real(signal_before[:n_show]), color=color_i,
             linewidth=1.2, label='I (réel)')
    ax1.plot(t_us, np.imag(signal_before[:n_show]), color=color_q,
             linewidth=1.2, label='Q (imaginaire)', alpha=0.8)

    ax1.set_title(f'Domaine temporel — AVANT\nfs = {fs_before/1e6:.2f} MHz',
                  color='white', fontsize=11, pad=10)
    ax1.set_xlabel('Temps (µs)', color='#aaaaaa', fontsize=9)
    ax1.set_ylabel('Amplitude', color='#aaaaaa', fontsize=9)
    ax1.tick_params(colors='#aaaaaa', labelsize=8)
    ax1.legend(fontsize=8, framealpha=0.3, labelcolor='white')
    ax1.grid(True, alpha=0.2, color='#444444')
    for spine in ax1.spines.values():
        spine.set_edgecolor('#333333')

    # ── 2. Spectre AVANT ──────────────────────────────────────────────────
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.set_facecolor('#1a1d2e')

    freqs_b, spec_b = compute_spectrum(signal_before, fs_before)
    ax2.plot(freqs_b, spec_b, color=color_spec_before, linewidth=1.0)
    ax2.fill_between(freqs_b, spec_b, alpha=0.15, color=color_spec_before)

    ax2.set_title(f'Spectre — AVANT\nfs = {fs_before/1e6:.2f} MHz  |  Signal centré à 0 Hz',
                  color='white', fontsize=11, pad=10)
    ax2.set_xlabel('Fréquence (MHz)', color='#aaaaaa', fontsize=9)
    ax2.set_ylabel('Amplitude (dB)', color='#aaaaaa', fontsize=9)
    ax2.set_xlim([-fs_before / 2 / 1e6, fs_before / 2 / 1e6])
    ax2.set_ylim([-80, 10])
    ax2.tick_params(colors='#aaaaaa', labelsize=8)
    ax2.grid(True, alpha=0.2, color='#444444')
    for spine in ax2.spines.values():
        spine.set_edgecolor('#333333')

    # ── 3. Domaine temporel APRÈS ─────────────────────────────────────────
    ax3 = fig.add_subplot(gs[1, 0])
    ax3.set_facecolor('#1a1d2e')

    n_show_after = min(300, len(signal_after))
    t_us_after = np.arange(n_show_after) / fs_after * 1e6

    ax3.plot(t_us_after, np.real(signal_after[:n_show_after]),
             color=color_i, linewidth=0.8, label='I (réel)')
    ax3.plot(t_us_after, np.imag(signal_after[:n_show_after]),
             color=color_q, linewidth=0.8, label='Q (imaginaire)', alpha=0.8)

    ax3.set_title(f'Domaine temporel — APRÈS transposition\nfs = {fs_after/1e6:.2f} MHz',
                  color='white', fontsize=11, pad=10)
    ax3.set_xlabel('Temps (µs)', color='#aaaaaa', fontsize=9)
    ax3.set_ylabel('Amplitude', color='#aaaaaa', fontsize=9)
    ax3.tick_params(colors='#aaaaaa', labelsize=8)
    ax3.legend(fontsize=8, framealpha=0.3, labelcolor='white')
    ax3.grid(True, alpha=0.2, color='#444444')
    for spine in ax3.spines.values():
        spine.set_edgecolor('#333333')

    # ── 4. Spectre APRÈS (zoom autour de f_shift) ─────────────────────────
    ax4 = fig.add_subplot(gs[1, 1])
    ax4.set_facecolor('#1a1d2e')

    freqs_a, spec_a = compute_spectrum(signal_after, fs_after)
    ax4.plot(freqs_a, spec_a, color=color_spec_after, linewidth=0.8)
    ax4.fill_between(freqs_a, spec_a, alpha=0.15, color=color_spec_after)

    # Ligne de référence à f_shift
    ax4.axvline(x=f_shift / 1e6, color='#ff4757', linewidth=1.5,
                linestyle='--', label=f'Cible : {f_shift/1e6:.0f} MHz', alpha=0.8)

    # Zoom autour de f_shift ± 200 MHz
    zoom_mhz = 200
    ax4.set_xlim([f_shift / 1e6 - zoom_mhz, f_shift / 1e6 + zoom_mhz])
    ax4.set_ylim([-80, 10])

    ax4.set_title(f'Spectre — APRÈS transposition\nZoom autour de {f_shift/1e6:.0f} MHz',
                  color='white', fontsize=11, pad=10)
    ax4.set_xlabel('Fréquence (MHz)', color='#aaaaaa', fontsize=9)
    ax4.set_ylabel('Amplitude (dB)', color='#aaaaaa', fontsize=9)
    ax4.tick_params(colors='#aaaaaa', labelsize=8)
    ax4.legend(fontsize=8, framealpha=0.3, labelcolor='white')
    ax4.grid(True, alpha=0.2, color='#444444')
    for spine in ax4.spines.values():
        spine.set_edgecolor('#333333')

    # Titre global
    fig.suptitle(
        f'Simulation 5G NR — Upsampling ×{int(fs_after/fs_before)} + Transposition {f_shift/1e6:.0f} MHz',
        color='white', fontsize=13, fontweight='bold', y=0.98
    )

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight',
                    facecolor=fig.get_facecolor())
        print(f"  Figure sauvegardée : {save_path}")

    plt.show()
