"""
signal_generator.py
Génération de signaux périodiques complexes pour simulation 5G NR
"""
import numpy as np


def generate_complex_tone(fs: float, f_signal: float, n_samples: int, amplitude: float = 1.0):
    """
    Génère un signal complexe périodique (exponentielle complexe) à f_signal Hz.

    Paramètres:
        fs        : sample rate baseband (Hz), ex: 122.88e6
        f_signal  : fréquence du signal (Hz), ex: 10e6
        n_samples : nombre d'échantillons
        amplitude : amplitude du signal

    Retourne:
        signal (ndarray complexe), t (ndarray temps en secondes)
    """
    t = np.arange(n_samples) / fs
    signal = amplitude * np.exp(1j * 2 * np.pi * f_signal * t)
    return signal, t


def generate_multi_tone(fs: float, frequencies: list, n_samples: int, amplitudes: list = None):
    """
    Génère une somme de sinusoïdes complexes — utile pour simuler
    plusieurs sous-porteuses actives dans un signal OFDM simplifié.

    Paramètres:
        fs          : sample rate (Hz)
        frequencies : liste de fréquences (Hz), ex: [5e6, 10e6, 20e6]
        n_samples   : nombre d'échantillons
        amplitudes  : liste d'amplitudes (1.0 par défaut pour chaque ton)

    Retourne:
        signal (ndarray complexe), t (ndarray temps en secondes)
    """
    if amplitudes is None:
        amplitudes = [1.0] * len(frequencies)

    t = np.arange(n_samples) / fs
    signal = np.zeros(n_samples, dtype=complex)

    for f, a in zip(frequencies, amplitudes):
        signal += a * np.exp(1j * 2 * np.pi * f * t)

    # Normalisation pour que l'amplitude max soit 1
    max_amp = np.max(np.abs(signal))
    if max_amp > 0:
        signal /= max_amp

    return signal, t
