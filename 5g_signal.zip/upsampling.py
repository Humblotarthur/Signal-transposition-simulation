"""
upsampling.py
Upsampling par zero-stuffing — augmente le sample rate d'un facteur L
pour permettre la transposition fréquentielle vers une fréquence cible.
"""
import numpy as np


def upsample_zero_stuffing(x: np.ndarray, L: int) -> np.ndarray:
    """
    Upsampling par insertion de zéros (zero stuffing).
    Insère L-1 zéros entre chaque sample original.

    Note: produit des images spectrales — pour un signal propre,
    appliquer upsample_with_filter(). Pour une preuve rapide,
    cette fonction seule suffit.

    Paramètres:
        x : signal complexe d'entrée (ndarray)
        L : facteur d'upsampling (entier), ex: 40

    Retourne:
        x_up : signal upsampleé (len = len(x) * L)

    Exemple:
        x     = [s0, s1, s2]          fs = 122.88 MHz
        L     = 4
        x_up  = [s0, 0, 0, 0, s1, 0, 0, 0, s2, 0, 0, 0]
                                       fs = 491.52 MHz
    """
    N = len(x)
    x_up = np.zeros(N * L, dtype=complex)
    x_up[::L] = x
    return x_up


def upsample_with_filter(x: np.ndarray, L: int, fs_base: float) -> np.ndarray:
    """
    Upsampling avec filtre passe-bas anti-images.
    Applique un filtre FIR après le zero stuffing pour supprimer
    les copies spectrales parasites.

    Paramètres:
        x       : signal complexe d'entrée
        L       : facteur d'upsampling
        fs_base : sample rate original (Hz), ex: 122.88e6

    Retourne:
        y : signal upsampleé et filtré
    """
    from scipy.signal import firwin, lfilter

    # Zero stuffing
    x_up = upsample_zero_stuffing(x, L)

    # Filtre passe-bas : coupe à fs_base/2
    fs_dac = fs_base * L
    fc_norm = (fs_base / 2) / (fs_dac / 2)  # fréquence normalisée 0..1

    n_taps = 101
    h = firwin(n_taps, fc_norm)

    # Application du filtre + compensation du gain
    y = lfilter(h, 1.0, x_up) * L

    return y
