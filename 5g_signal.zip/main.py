"""
main.py
Script principal — simulation upsampling + transposition fréquentielle 5G NR

Chaîne simulée :
  Signal baseband (122.88 MHz)
      → Upsampling ×40 (zero stuffing)
      → Transposition NCO à 1 GHz  [équivalent cycShiftFD_asm : y = x .* NCO]
      → Visualisation avant / après
"""

from signal_generator import generate_multi_tone
from upsampling import upsample_zero_stuffing
from transposition import apply_frequency_shift
from plotting import plot_before_after

# ─── Paramètres ───────────────────────────────────────────────────────────────

FS_BASE    = 122.88e6   # Sample rate baseband 5G NR (Hz)
F_CIBLE    = 1000e6     # Fréquence de transposition souhaitée (Hz) → 1 GHz
L          = 40         # Facteur d'upsampling  →  fs_DAC = 40 × 122.88 = 4915.2 MHz
N_SAMPLES  = 4096       # Nombre d'échantillons baseband

FS_DAC = FS_BASE * L    # Sample rate après upsampling

# Signal de test : 3 tonalités dans la bande baseband (simule quelques sous-porteuses)
FREQUENCES_TEST = [5e6, 15e6, 30e6]   # Hz — bien dans ±61.44 MHz

# ─── Pipeline ─────────────────────────────────────────────────────────────────

print("=" * 55)
print("  Simulation 5G NR — Upsampling + Transposition")
print("=" * 55)

# 1. Génération du signal baseband
print(f"\n[1] Génération du signal...")
print(f"    Fréquences : {[f/1e6 for f in FREQUENCES_TEST]} MHz")
print(f"    N samples  : {N_SAMPLES}")
print(f"    fs baseband: {FS_BASE/1e6:.2f} MHz")

signal_bb, t = generate_multi_tone(FS_BASE, FREQUENCES_TEST, N_SAMPLES)
print(f"    → Signal complexe généré : {len(signal_bb)} samples")

# 2. Upsampling par zero stuffing
print(f"\n[2] Upsampling ×{L}...")
print(f"    fs avant  : {FS_BASE/1e6:.2f} MHz")
print(f"    fs après  : {FS_DAC/1e6:.2f} MHz")

signal_up = upsample_zero_stuffing(signal_bb, L)
print(f"    → Signal upsampleé : {len(signal_up)} samples")
print(f"    ⚠  Images spectrales présentes (pas de filtre passe-bas ici)")

# 3. Transposition à 1 GHz (équivalent cycShiftFD_asm : y = x .* NCO)
print(f"\n[3] Transposition à {F_CIBLE/1e6:.0f} MHz...")
print(f"    fs_DAC     : {FS_DAC/1e6:.2f} MHz")

signal_shifted = apply_frequency_shift(signal_up, F_CIBLE, FS_DAC)
print(f"    → Signal décalé : pic principal attendu à {F_CIBLE/1e6:.0f} MHz")

# 4. Résumé
print(f"\n{'─'*55}")
print(f"  RÉSUMÉ")
print(f"{'─'*55}")
print(f"  Signal original  : {FS_BASE/1e6:.2f} MHz  |  {N_SAMPLES} samples")
print(f"  Après upsampling : {FS_DAC/1e6:.2f} MHz  |  {len(signal_up)} samples")
print(f"  Fréquence cible  : {F_CIBLE/1e6:.0f} MHz")
print(f"  f_normalisée NCO : {F_CIBLE/FS_DAC:.6f}")
print(f"{'─'*55}\n")

# 5. Visualisation
print("[4] Affichage des graphes...")
plot_before_after(
    signal_before=signal_bb,
    signal_after=signal_shifted,
    fs_before=FS_BASE,
    fs_after=FS_DAC,
    f_shift=F_CIBLE,
    save_path="resultat_transposition.png"
)

print("\nTerminé.")
