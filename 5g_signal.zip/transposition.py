"""
transposition.py
Décalage fréquentiel numérique par multiplication NCO.
Equivalent Python de cycShiftFD_asm : y = x .* NCO
"""
import numpy as np


def nco_generate(f_shift: float, fs: float, n_samples: int, phase_init: float = 0.0) -> np.ndarray:
    """
    Génère un NCO (Numerically Controlled Oscillator).
    Produit la suite : NCO[n] = exp(j * 2π * (f_shift/fs) * n)

    Paramètres:
        f_shift    : fréquence de décalage souhaitée (Hz), ex: 1e9
        fs         : sample rate du signal à décaler (Hz), ex: 4915.2e6
        n_samples  : nombre d'échantillons
        phase_init : phase initiale en radians (0 par défaut)

    Retourne:
        nco : signal complexe (ndarray)
    """
    f_norm = f_shift / fs
    print(f"  NCO → fréquence normalisée : {f_norm:.6f}  (doit être entre -0.5 et +0.5)")

    n = np.arange(n_samples)
    nco = np.exp(1j * (2 * np.pi * f_norm * n + phase_init))
    return nco


def apply_frequency_shift(x: np.ndarray, f_shift: float, fs: float) -> np.ndarray:
    """
    Applique un décalage fréquentiel au signal x.
    Opération : y = x .* NCO  (équivalent de cycShiftFD_asm)

    Paramètres:
        x       : signal complexe d'entrée (après upsampling)
        f_shift : fréquence cible (Hz), ex: 1e9
        fs      : sample rate du signal upsampleé (Hz)

    Retourne:
        y : signal décalé en fréquence
    """
    N = len(x)
    nco = nco_generate(f_shift, fs, N)
    y = x * nco
    return y
